#define VERSION \
"LIBTIFF, Version 3.4beta028 \n"\
"Copyright (c) 1988-1995 Sam Leffler\n"\
"Copyright (c) 1991-1996 Silicon Graphics, Inc."
