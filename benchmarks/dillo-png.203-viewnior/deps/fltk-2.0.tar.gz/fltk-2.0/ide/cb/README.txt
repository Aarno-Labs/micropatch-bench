Code::Blocks
============


This directory contains Code::Blocks (http://www.codeblocks.org) workspace
and project files..
In order to build FLTK inside Code::Blocks you will have to propely setup chosen
subsystems.

All files in this directory are NOT officialy supported, and serve only the purpose
of helping FLTK team in easier/faster development.

As You probably notice, I made only a "fltk" project, for building static FLTK library. I hope I'll have more time in the future to make "fltk-images", "fltk-opengl" and "fluid" projects.

Note for FLTK developers
------------------------

Developers should naturally commit only fltk.workspace, and .cbp files. 
All other files are not needed in our subversion repository, because they 
are automatically generated.

-------------------------------------------------------------------------
$Id$
