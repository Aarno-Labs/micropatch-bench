#!/bin/sh

java -cp leaksoup leaksoup $1
