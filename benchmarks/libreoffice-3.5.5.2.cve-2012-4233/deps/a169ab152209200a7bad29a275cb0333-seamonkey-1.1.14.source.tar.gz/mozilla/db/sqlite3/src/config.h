
#ifndef _sqlite3_config_h
#define _sqlite3_config_h

#include "prcpucfg.h"

#define HAVE_USLEEP 1

#define SQLITE_PTR_SZ PR_BYTES_PER_WORD

#endif /* _sqlite3_config_h */
